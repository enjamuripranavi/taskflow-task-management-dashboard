import React, { useState, useEffect, useMemo } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { SummaryCards } from './components/SummaryCards';
import { TaskList } from './components/TaskList';
import { TaskFormModal } from './components/TaskFormModal';
import { ConfirmModal } from './components/ConfirmModal';
import { INITIAL_TASKS } from './data/initialTasks';
import './styles/App.css';
import './styles/Components.css';

const STORAGE_KEY = 'taskflow_tasks';

export function App() {
  // Load tasks from localStorage or fall back to realistic sample data
  const [tasks, setTasks] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed;
        }
      }
    } catch (error) {
      console.warn('Could not read tasks from localStorage, initializing with defaults.', error);
    }
    return INITIAL_TASKS;
  });

  // Active status filter: 'All' | 'Pending' | 'In Progress' | 'Completed'
  const [activeFilter, setActiveFilter] = useState('All');

  // Search query for title
  const [searchQuery, setSearchQuery] = useState('');

  // Active sorting option
  const [sortBy, setSortBy] = useState('newest');

  // Mobile sidebar visibility
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Modal states
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [taskToEdit, setTaskToEdit] = useState(null);
  const [taskToDelete, setTaskToDelete] = useState(null);

  // Persist tasks in localStorage whenever tasks state changes
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
    } catch (error) {
      console.error('Failed to save tasks to localStorage:', error);
    }
  }, [tasks]);

  // Derive counts for sidebar and summary cards
  const counts = useMemo(() => {
    let pending = 0;
    let inProgress = 0;
    let completed = 0;

    for (const task of tasks) {
      if (task.status === 'Pending') pending++;
      else if (task.status === 'In Progress') inProgress++;
      else if (task.status === 'Completed') completed++;
    }

    return {
      all: tasks.length,
      pending,
      inProgress,
      completed,
    };
  }, [tasks]);

  // Combined filtering & sorting: Status filter + Search query + Sorting
  const filteredAndSortedTasks = useMemo(() => {
    const trimmedQuery = searchQuery.trim().toLowerCase();

    // 1. Filter tasks by status and title search
    const filtered = tasks.filter((task) => {
      const matchesFilter =
        activeFilter === 'All' ? true : task.status === activeFilter;

      const matchesSearch =
        trimmedQuery === ''
          ? true
          : task.title.toLowerCase().includes(trimmedQuery);

      return matchesFilter && matchesSearch;
    });

    // 2. Sort a shallow copy so original task data remains untouched
    const priorityWeights = {
      High: 3,
      Medium: 2,
      Low: 1,
    };

    return [...filtered].sort((a, b) => {
      switch (sortBy) {
        case 'newest':
          return new Date(b.createdAt) - new Date(a.createdAt);

        case 'oldest':
          return new Date(a.createdAt) - new Date(b.createdAt);

        case 'priority-desc': {
          const diff =
            (priorityWeights[b.priority] || 0) - (priorityWeights[a.priority] || 0);
          return diff !== 0
            ? diff
            : new Date(b.createdAt) - new Date(a.createdAt);
        }

        case 'priority-asc': {
          const diff =
            (priorityWeights[a.priority] || 0) - (priorityWeights[b.priority] || 0);
          return diff !== 0
            ? diff
            : new Date(b.createdAt) - new Date(a.createdAt);
        }

        case 'title-asc':
          return a.title.localeCompare(b.title, undefined, { sensitivity: 'base' });

        case 'title-desc':
          return b.title.localeCompare(a.title, undefined, { sensitivity: 'base' });

        default:
          return 0;
      }
    });
  }, [tasks, activeFilter, searchQuery, sortBy]);

  // Handlers
  const handleOpenAddTask = () => {
    setTaskToEdit(null);
    setIsFormOpen(true);
  };

  const handleOpenEditTask = (task) => {
    setTaskToEdit(task);
    setIsFormOpen(true);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setTaskToEdit(null);
  };

  // Create or Update task
  const handleFormSubmit = (taskData) => {
    if (taskData.id) {
      // Editing existing task
      setTasks((prevTasks) =>
        prevTasks.map((t) => (t.id === taskData.id ? { ...t, ...taskData } : t))
      );
    } else {
      // Adding new task
      const newTask = {
        ...taskData,
        id: `task-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        createdAt: new Date().toISOString(),
      };
      setTasks((prevTasks) => [newTask, ...prevTasks]);
    }
    handleCloseForm();
  };

  // Direct status change from TaskItem
  const handleStatusChange = (taskId, newStatus) => {
    setTasks((prevTasks) =>
      prevTasks.map((task) =>
        task.id === taskId ? { ...task, status: newStatus } : task
      )
    );
  };

  // Delete flow with confirmation
  const handleRequestDelete = (task) => {
    setTaskToDelete(task);
  };

  const handleConfirmDelete = () => {
    if (taskToDelete) {
      setTasks((prevTasks) => prevTasks.filter((t) => t.id !== taskToDelete.id));
      setTaskToDelete(null);
    }
  };

  const handleCancelDelete = () => {
    setTaskToDelete(null);
  };

  return (
    <div className="taskflow-app">
      {/* Top Header */}
      <Header
        onOpenAddTask={handleOpenAddTask}
        onToggleMobileSidebar={() => setMobileSidebarOpen((prev) => !prev)}
      />

      <div className="dashboard-shell">
        {/* Navigation Sidebar */}
        <Sidebar
          activeFilter={activeFilter}
          onSelectFilter={setActiveFilter}
          counts={counts}
          mobileOpen={mobileSidebarOpen}
          onCloseMobile={() => setMobileSidebarOpen(false)}
        />

        {/* Main Content Area */}
        <main className="dashboard-main" id="main-content">
          <div className="main-container">
            {/* Summary Metrics Cards */}
            <SummaryCards
              counts={counts}
              activeFilter={activeFilter}
              onSelectFilter={setActiveFilter}
            />

            {/* Task List Section */}
            <TaskList
              tasks={filteredAndSortedTasks}
              totalTasksCount={tasks.length}
              activeFilter={activeFilter}
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
              onClearSearch={() => setSearchQuery('')}
              sortBy={sortBy}
              onSortChange={setSortBy}
              onResetFilter={() => setActiveFilter('All')}
              onEditTask={handleOpenEditTask}
              onDeleteTask={handleRequestDelete}
              onStatusChange={handleStatusChange}
              onOpenAddTask={handleOpenAddTask}
            />
          </div>
        </main>
      </div>

      {/* Task Creation / Edit Modal */}
      <TaskFormModal
        isOpen={isFormOpen}
        onClose={handleCloseForm}
        onSubmit={handleFormSubmit}
        taskToEdit={taskToEdit}
      />

      {/* Delete Confirmation Modal */}
      <ConfirmModal
        isOpen={Boolean(taskToDelete)}
        taskTitle={taskToDelete ? taskToDelete.title : ''}
        onConfirm={handleConfirmDelete}
        onCancel={handleCancelDelete}
      />
    </div>
  );
}

export default App;
