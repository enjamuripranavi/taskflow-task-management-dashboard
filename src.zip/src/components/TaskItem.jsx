import React from 'react';
import { IconEdit, IconTrash } from './Icons';

export const TaskItem = ({ task, onEdit, onDelete, onStatusChange }) => {
  const getPriorityClass = (priority) => {
    switch (priority) {
      case 'High':
        return 'priority-high';
      case 'Medium':
        return 'priority-medium';
      case 'Low':
        return 'priority-low';
      default:
        return 'priority-medium';
    }
  };

  const getStatusClass = (status) => {
    switch (status) {
      case 'Completed':
        return 'status-completed';
      case 'In Progress':
        return 'status-in-progress';
      case 'Pending':
        return 'status-pending';
      default:
        return 'status-pending';
    }
  };

  // Format date readable
  const formattedDate = task.createdAt
    ? new Date(task.createdAt).toLocaleDateString(undefined, {
        month: 'short',
        day: 'numeric',
      })
    : '';

  return (
    <article className={`task-item ${task.status === 'Completed' ? 'is-completed' : ''}`}>
      <div className="task-main-col">
        <div className="task-header-row">
          <span className={`priority-badge ${getPriorityClass(task.priority)}`}>
            {task.priority} Priority
          </span>
          <span className={`status-badge ${getStatusClass(task.status)}`}>
            <span className="status-dot" aria-hidden="true" />
            {task.status}
          </span>
          {formattedDate && <span className="task-date">{formattedDate}</span>}
        </div>

        <h3 className="task-title" title={task.title}>
          {task.title}
        </h3>
      </div>

      <div className="task-actions-col">
        <div className="status-select-wrap">
          <label htmlFor={`status-select-${task.id}`} className="sr-only">
            Change status for {task.title}
          </label>
          <select
            id={`status-select-${task.id}`}
            className="task-status-select"
            value={task.status}
            onChange={(e) => onStatusChange(task.id, e.target.value)}
          >
            <option value="Pending">Pending</option>
            <option value="In Progress">In Progress</option>
            <option value="Completed">Completed</option>
          </select>
        </div>

        <div className="task-btn-group">
          <button
            type="button"
            className="btn-action btn-edit"
            onClick={() => onEdit(task)}
            title="Edit task"
            aria-label={`Edit task "${task.title}"`}
          >
            <IconEdit size={15} />
            <span className="action-text">Edit</span>
          </button>

          <button
            type="button"
            className="btn-action btn-delete"
            onClick={() => onDelete(task)}
            title="Delete task"
            aria-label={`Delete task "${task.title}"`}
          >
            <IconTrash size={15} />
            <span className="action-text">Delete</span>
          </button>
        </div>
      </div>
    </article>
  );
};
