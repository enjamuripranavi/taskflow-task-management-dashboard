import React from 'react';
import { IconTotal, IconClock, IconInProgress, IconCheckCircle } from './Icons';

export const SummaryCards = ({ counts, activeFilter, onSelectFilter }) => {
  const cards = [
    {
      id: 'All',
      label: 'Total Tasks',
      count: counts.all,
      icon: <IconTotal size={20} />,
      accentClass: 'card-total',
    },
    {
      id: 'Pending',
      label: 'Pending Tasks',
      count: counts.pending,
      icon: <IconClock size={20} />,
      accentClass: 'card-pending',
    },
    {
      id: 'In Progress',
      label: 'In Progress Tasks',
      count: counts.inProgress,
      icon: <IconInProgress size={20} />,
      accentClass: 'card-progress',
    },
    {
      id: 'Completed',
      label: 'Completed Tasks',
      count: counts.completed,
      icon: <IconCheckCircle size={20} />,
      accentClass: 'card-completed',
    },
  ];

  return (
    <section className="summary-section" aria-label="Task Summary Overview">
      <div className="summary-grid">
        {cards.map((card) => {
          const isSelected = activeFilter === card.id;
          return (
            <button
              key={card.id}
              type="button"
              className={`summary-card ${card.accentClass} ${isSelected ? 'selected' : ''}`}
              onClick={() => onSelectFilter(card.id)}
              aria-label={`Filter by ${card.label}: ${card.count} tasks`}
            >
              <div className="card-top">
                <span className="card-label">{card.label}</span>
                <div className="card-icon-wrap" aria-hidden="true">
                  {card.icon}
                </div>
              </div>
              <div className="card-bottom">
                <span className="card-number">{card.count}</span>
                <span className="card-hint">
                  {isSelected ? 'Active filter' : 'Click to filter'}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </section>
  );
};
