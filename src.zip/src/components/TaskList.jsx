import React from 'react';
import { TaskItem } from './TaskItem';
import { IconSearch, IconClose, IconPlus } from './Icons';

export const TaskList = ({
  tasks,
  totalTasksCount,
  activeFilter,
  searchQuery,
  onSearchChange,
  onClearSearch,
  sortBy,
  onSortChange,
  onResetFilter,
  onEditTask,
  onDeleteTask,
  onStatusChange,
  onOpenAddTask,
}) => {
  const isSearchActive = searchQuery.trim().length > 0;
  const isFiltered = activeFilter !== 'All';

  return (
    <section className="task-list-section" aria-label="Tasks List">
      {/* Top Controls: Search Bar, Sort Dropdown & Info */}
      <div className="task-list-controls">
        <div className="search-sort-group">
          <div className="search-input-wrapper">
            <IconSearch className="search-icon" size={17} />
            <input
              type="text"
              className="search-input"
              placeholder="Search tasks by title..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              aria-label="Search tasks by title"
            />
            {isSearchActive && (
              <button
                type="button"
                className="search-clear-btn"
                onClick={onClearSearch}
                aria-label="Clear search text"
              >
                <IconClose size={15} />
              </button>
            )}
          </div>

          <div className="sort-select-wrapper">
            <label htmlFor="task-sort-select" className="sort-label">
              Sort:
            </label>
            <select
              id="task-sort-select"
              className="sort-select"
              value={sortBy}
              onChange={(e) => onSortChange(e.target.value)}
              aria-label="Sort tasks"
            >
              <option value="newest">Newest first</option>
              <option value="oldest">Oldest first</option>
              <option value="priority-desc">Priority: High to Low</option>
              <option value="priority-asc">Priority: Low to High</option>
              <option value="title-asc">Title: A to Z</option>
              <option value="title-desc">Title: Z to A</option>
            </select>
          </div>
        </div>

        <div className="task-list-meta">
          <div className="meta-filter-badge">
            <span className="meta-label">Viewing:</span>
            <span className="meta-filter-name">{activeFilter} Tasks</span>
            {isFiltered && (
              <button
                type="button"
                className="meta-clear-filter-btn"
                onClick={onResetFilter}
                title="Reset to All Tasks"
              >
                Reset
              </button>
            )}
          </div>
          <span className="meta-count">
            {tasks.length} {tasks.length === 1 ? 'task' : 'tasks'}
          </span>
        </div>
      </div>

      {/* Task List Items or Empty State */}
      <div className="task-items-container">
        {tasks.length > 0 ? (
          tasks.map((task) => (
            <TaskItem
              key={task.id}
              task={task}
              onEdit={onEditTask}
              onDelete={onDeleteTask}
              onStatusChange={onStatusChange}
            />
          ))
        ) : (
          <div className="empty-state-card">
            <div className="empty-state-graphic" aria-hidden="true">
              <IconSearch size={32} />
            </div>

            {totalTasksCount === 0 ? (
              <>
                <h3 className="empty-state-title">No tasks in your dashboard yet</h3>
                <p className="empty-state-desc">
                  Start organizing your day by creating your first task above.
                </p>
                <button
                  type="button"
                  className="btn-primary empty-action-btn"
                  onClick={onOpenAddTask}
                >
                  <IconPlus size={16} />
                  <span>Create First Task</span>
                </button>
              </>
            ) : isSearchActive ? (
              <>
                <h3 className="empty-state-title">No matching tasks found</h3>
                <p className="empty-state-desc">
                  No tasks match your search for{' '}
                  <strong>"{searchQuery}"</strong>{' '}
                  {isFiltered && `within the ${activeFilter} filter`}.
                </p>
                <div className="empty-state-buttons">
                  <button
                    type="button"
                    className="btn-secondary"
                    onClick={onClearSearch}
                  >
                    Clear Search
                  </button>
                  {isFiltered && (
                    <button
                      type="button"
                      className="btn-primary"
                      onClick={onResetFilter}
                    >
                      Show All Tasks
                    </button>
                  )}
                </div>
              </>
            ) : (
              <>
                <h3 className="empty-state-title">No {activeFilter} tasks</h3>
                <p className="empty-state-desc">
                  There are currently no tasks with "{activeFilter}" status.
                </p>
                <div className="empty-state-buttons">
                  <button
                    type="button"
                    className="btn-secondary"
                    onClick={onResetFilter}
                  >
                    Return to All Tasks
                  </button>
                  <button
                    type="button"
                    className="btn-primary"
                    onClick={onOpenAddTask}
                  >
                    <IconPlus size={16} />
                    <span>Add Task</span>
                  </button>
                </div>
              </>
            )}
          </div>
        )}
      </div>
    </section>
  );
};
