import React from 'react';
import {
  IconTotal,
  IconClock,
  IconInProgress,
  IconCheckCircle,
  IconClose,
} from './Icons';

export const Sidebar = ({
  activeFilter,
  onSelectFilter,
  counts,
  mobileOpen,
  onCloseMobile,
}) => {
  const filterItems = [
    {
      id: 'All',
      label: 'All Tasks',
      icon: <IconTotal size={17} />,
      count: counts.all,
    },
    {
      id: 'Pending',
      label: 'Pending',
      icon: <IconClock size={17} />,
      count: counts.pending,
    },
    {
      id: 'In Progress',
      label: 'In Progress',
      icon: <IconInProgress size={17} />,
      count: counts.inProgress,
    },
    {
      id: 'Completed',
      label: 'Completed',
      icon: <IconCheckCircle size={17} />,
      count: counts.completed,
    },
  ];

  const handleSelect = (id) => {
    onSelectFilter(id);
    if (onCloseMobile) {
      onCloseMobile();
    }
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div
          className="sidebar-backdrop"
          onClick={onCloseMobile}
          aria-hidden="true"
        />
      )}

      <aside className={`app-sidebar ${mobileOpen ? 'mobile-open' : ''}`}>
        <div className="sidebar-header">
          <span className="sidebar-title">Navigation</span>
          <button
            type="button"
            className="sidebar-close-btn"
            onClick={onCloseMobile}
            aria-label="Close navigation menu"
          >
            <IconClose size={18} />
          </button>
        </div>

        <nav className="sidebar-nav" aria-label="Task Status Filters">
          <ul className="sidebar-menu">
            {filterItems.map((item) => {
              const isActive = activeFilter === item.id;
              return (
                <li key={item.id}>
                  <button
                    type="button"
                    className={`sidebar-nav-item ${isActive ? 'active' : ''}`}
                    onClick={() => handleSelect(item.id)}
                    aria-current={isActive ? 'page' : undefined}
                  >
                    <span className="sidebar-item-icon">{item.icon}</span>
                    <span className="sidebar-item-label">{item.label}</span>
                    <span className="sidebar-item-count">{item.count}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="sidebar-footer">
          <div className="sidebar-info-card">
            <span className="info-title">TaskFlow v0.1</span>
            <span className="info-subtitle">Local storage active</span>
          </div>
        </div>
      </aside>
    </>
  );
};
