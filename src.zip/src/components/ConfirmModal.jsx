import React, { useEffect, useRef } from 'react';
import { IconWarning, IconClose } from './Icons';

export const ConfirmModal = ({ isOpen, taskTitle, onConfirm, onCancel }) => {
  const cancelBtnRef = useRef(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        if (cancelBtnRef.current) {
          cancelBtnRef.current.focus();
        }
      }, 50);

      const handleKeyDown = (e) => {
        if (e.key === 'Escape') {
          onCancel();
        }
      };
      window.addEventListener('keydown', handleKeyDown);
      return () => window.removeEventListener('keydown', handleKeyDown);
    }
  }, [isOpen, onCancel]);

  if (!isOpen) return null;

  return (
    <div
      className="modal-backdrop"
      onClick={onCancel}
      role="dialog"
      aria-modal="true"
      aria-labelledby="confirm-modal-title"
    >
      <div
        className="modal-card modal-confirm-card"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="confirm-icon-wrap" aria-hidden="true">
          <IconWarning size={28} />
        </div>

        <div className="confirm-content">
          <h2 id="confirm-modal-title" className="confirm-title">
            Delete Task
          </h2>
          <p className="confirm-desc">
            Are you sure you want to delete{' '}
            <strong className="confirm-target-title">
              "{taskTitle}"
            </strong>
            ? This action cannot be undone.
          </p>
        </div>

        <div className="modal-actions confirm-actions">
          <button
            type="button"
            ref={cancelBtnRef}
            className="btn-secondary"
            onClick={onCancel}
          >
            Cancel
          </button>
          <button
            type="button"
            className="btn-danger"
            onClick={onConfirm}
          >
            Delete Task
          </button>
        </div>
      </div>
    </div>
  );
};
