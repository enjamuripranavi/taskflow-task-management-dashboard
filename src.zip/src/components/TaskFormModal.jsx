import React, { useState, useEffect, useRef } from 'react';
import { IconClose } from './Icons';

export const TaskFormModal = ({ isOpen, onClose, onSubmit, taskToEdit }) => {
  const [title, setTitle] = useState('');
  const [priority, setPriority] = useState('Medium');
  const [status, setStatus] = useState('Pending');
  const [error, setError] = useState('');
  const inputRef = useRef(null);

  const isEditing = Boolean(taskToEdit);

  // Sync state whenever taskToEdit changes or modal opens
  useEffect(() => {
    if (isOpen) {
      if (taskToEdit) {
        setTitle(taskToEdit.title || '');
        setPriority(taskToEdit.priority || 'Medium');
        setStatus(taskToEdit.status || 'Pending');
      } else {
        setTitle('');
        setPriority('Medium');
        setStatus('Pending');
      }
      setError('');
      // Focus title input on open
      setTimeout(() => {
        if (inputRef.current) {
          inputRef.current.focus();
        }
      }, 50);
    }
  }, [isOpen, taskToEdit]);

  // Handle ESC key to close modal
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    const trimmedTitle = title.trim();

    if (!trimmedTitle) {
      setError('Task title is required. Please enter a valid title.');
      if (inputRef.current) {
        inputRef.current.focus();
      }
      return;
    }

    onSubmit({
      id: taskToEdit ? taskToEdit.id : undefined,
      title: trimmedTitle,
      priority,
      status,
      createdAt: taskToEdit ? taskToEdit.createdAt : new Date().toISOString(),
    });

    onClose();
  };

  return (
    <div
      className="modal-backdrop"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
    >
      <div
        className="modal-card"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="modal-header">
          <div>
            <h2 id="modal-title" className="modal-title">
              {isEditing ? 'Edit Task' : 'Create New Task'}
            </h2>
            <p className="modal-subtitle">
              {isEditing
                ? 'Update the details and priority for this task.'
                : 'Fill in the information below to add a task to your dashboard.'}
            </p>
          </div>
          <button
            type="button"
            className="modal-close-btn"
            onClick={onClose}
            aria-label="Close dialog"
          >
            <IconClose size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="modal-form" noValidate>
          <div className="form-group">
            <label htmlFor="task-title" className="form-label">
              Task Title <span className="required-star">*</span>
            </label>
            <input
              id="task-title"
              ref={inputRef}
              type="text"
              className={`form-input ${error ? 'input-error' : ''}`}
              placeholder="e.g., Complete project documentation"
              value={title}
              onChange={(e) => {
                setTitle(e.target.value);
                if (error) setError('');
              }}
              maxLength={120}
            />
            {error ? (
              <span className="form-error-text" role="alert">
                {error}
              </span>
            ) : (
              <span className="form-help-text">
                Be clear and specific (up to 120 characters).
              </span>
            )}
          </div>

          <div className="form-row">
            <div className="form-group half-width">
              <label htmlFor="task-priority" className="form-label">
                Priority
              </label>
              <select
                id="task-priority"
                className="form-select"
                value={priority}
                onChange={(e) => setPriority(e.target.value)}
              >
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
              </select>
            </div>

            <div className="form-group half-width">
              <label htmlFor="task-status" className="form-label">
                Status
              </label>
              <select
                id="task-status"
                className="form-select"
                value={status}
                onChange={(e) => setStatus(e.target.value)}
              >
                <option value="Pending">Pending</option>
                <option value="In Progress">In Progress</option>
                <option value="Completed">Completed</option>
              </select>
            </div>
          </div>

          <div className="modal-actions">
            <button
              type="button"
              className="btn-secondary"
              onClick={onClose}
            >
              Cancel
            </button>
            <button type="submit" className="btn-primary">
              {isEditing ? 'Save Changes' : 'Add Task'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
