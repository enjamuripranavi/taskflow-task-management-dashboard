import React from 'react';
import { IconLogo, IconPlus, IconMenu } from './Icons';

export const Header = ({ onOpenAddTask, onToggleMobileSidebar }) => {
  return (
    <header className="app-header">
      <div className="header-left">
        <button
          type="button"
          className="mobile-menu-btn"
          onClick={onToggleMobileSidebar}
          aria-label="Toggle navigation menu"
        >
          <IconMenu size={20} />
        </button>

        <div className="brand-container">
          <div className="brand-icon">
            <IconLogo size={20} />
          </div>
          <span className="brand-name">TaskFlow</span>
        </div>
      </div>

      <div className="header-center">
        <div className="header-titles">
          <h1 className="header-page-title">Task Dashboard</h1>
          <p className="header-welcome-msg">Manage your daily tasks and keep track of your workflow.</p>
        </div>
      </div>

      <div className="header-right">
        <button
          type="button"
          className="btn-primary add-task-btn"
          onClick={onOpenAddTask}
          aria-label="Add new task"
        >
          <IconPlus size={16} />
          <span>Add Task</span>
        </button>

        <div className="workspace-indicator" title="Personal Workspace">
          <div className="workspace-avatar" aria-hidden="true">AR</div>
          <div className="workspace-details">
            <span className="workspace-name">Alex Rivera</span>
            <span className="workspace-badge">Personal</span>
          </div>
        </div>
      </div>
    </header>
  );
};
