/**
 * Initial sample tasks for TaskFlow
 * Realistic starter tasks for demonstration covering various priorities and statuses.
 */
export const INITIAL_TASKS = [
  {
    id: 'task-1',
    title: 'Complete React assignment',
    priority: 'High',
    status: 'In Progress',
    createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'task-2',
    title: 'Review JavaScript fundamentals',
    priority: 'Medium',
    status: 'Completed',
    createdAt: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'task-3',
    title: 'Prepare project documentation',
    priority: 'Medium',
    status: 'Pending',
    createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'task-4',
    title: 'Test the dashboard responsive layouts',
    priority: 'Low',
    status: 'Pending',
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
  },
];
